# zeet-flask
Simple Flask application that can be deployed to Zeet.

# Walkthrough
https://www.youtube.com/watch?v=p8IY8bSIg7U

# Sign up to Zeet
https://go.zeet.co/devopsjourney

# Other Types of projects? Django, Golang, Node.js etc.
Zeet supports more then just AWS/Flask.  You can follow the tutorial and deploy to any Cloud Provider using a Framework of your choosing such as Django, Node.js, Golang etc.  more project examples located in the Zeet documentation https://docs.zeet.co/reference/introduction
